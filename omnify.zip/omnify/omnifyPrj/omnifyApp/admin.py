from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(Fitness)
admin.site.register(Book)
